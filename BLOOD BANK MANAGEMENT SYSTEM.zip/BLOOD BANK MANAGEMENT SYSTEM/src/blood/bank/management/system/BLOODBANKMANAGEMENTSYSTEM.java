package blood.bank.management.system;

public class BLOODBANKMANAGEMENTSYSTEM {

   
    public static void main(String[] args) {
       
    }
    
}
