
package bloodbankmanagementsystem;

import java.sql.*;
public class databaseConnection {
    public static Connection establishConnection(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection cn=DriverManager.getConnection("jdbc:mysql://localhost/blood_bank_management_system_database", "root", null);
            return cn;
        }
        catch(Exception e){
             e.printStackTrace();
            return null;
        }
    }
}
